﻿using QRCoder;

Console.WriteLine("Digite a url para gerar o grcode");
string url = Console.ReadLine();

if (string.IsNullOrEmpty(url))
{
    Console.WriteLine("Formato de url invalida.");
    return;
}

try
{
    QRCodeGenerator qRCodeGenerator = new();
    QRCodeData qRCodeData = qRCodeGenerator.CreateQrCode(url, QRCodeGenerator.ECCLevel.Q);
    using (PngByteQRCode qrcode = new PngByteQRCode(qRCodeData))
    {
        byte[] qrcodeimage = qrcode.GetGraphic(20);

        //salva a imagem na area de trabalho
        string desktopath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        string filepath = Path.Combine(desktopath, "qrcode.png");
            
        //salva os array de bytes como um arquivo png
        File.WriteAllBytes(filepath, qrcodeimage);

        Console.WriteLine($"QRcode gerado com sucesso e salvo em: {filepath}");

    }
}
catch (Exception ex)
{
    Console.WriteLine($"Erro ao gerar o qrcode: {ex.Message}");
}