﻿Console.WriteLine("insira um valor (true ou false):");
bool valor1 = Convert.ToBoolean(Console.ReadLine());

Console.WriteLine("insira um valor (true ou false):");
bool valor2 = Convert.ToBoolean(Console.ReadLine());

if (valor1 == true && valor2 == true)
{
    Console.WriteLine("O valor 1 recebeu VERDADEIRO e valor 2 VERDADEIRO");
}
else if (valor1 == false && valor2 == true)
{
    Console.WriteLine("O valor 1 recebeu FALSO e valor 2 VERDADEIRO");
}
else if (valor1 == true && valor2 == false)
{
    Console.WriteLine("O valor 1 recebeu VERDADEIRO e valor 2 FALSO");
}
else if (valor1 == false && valor2 == true)
{
    Console.WriteLine("O valor 1 recebeu FALSO e valor 2 VERDADEIRO");
}