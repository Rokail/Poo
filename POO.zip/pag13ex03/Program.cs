﻿using Pag13ex03;

Console.WriteLine("Insira um valor para A:");
int A = int.Parse(Console.ReadLine());

Console.WriteLine("Insira um valor para B:");
int B = int.Parse(Console.ReadLine());

Console.WriteLine("Insira um valor para C:");
int C = int.Parse(Console.ReadLine());

Equacao equa = new Equacao();

Console.WriteLine("O valor de A e B é: " + equa.somarfator(A,B));

if (equa.somarfator(A, B) < C)
{
    Console.WriteLine("O valor da C é maior que a soma de A e B.");
}