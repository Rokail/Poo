﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pag13ex03
{
    class Equacao
    {
        int A;
        int B;
        int C;

        public int somarfator(int A, int B)
        {
            return A + B;
        }

    }
}
