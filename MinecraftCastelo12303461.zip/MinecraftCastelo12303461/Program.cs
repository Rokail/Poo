﻿using MinecraftCastelo12303461.Context;

using var db = new CasteloContext(); 

Console.WriteLine("+===========================+");
Console.WriteLine("Insira o material a ser usado\n1. madeira \n2. Ouro \n3. Diamante");