﻿namespace MinecraftCastelo12303461.Enum;
public enum Material
{
    Madeira,
    ouro,
    diamante
}
