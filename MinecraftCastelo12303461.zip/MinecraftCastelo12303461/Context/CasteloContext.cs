﻿using Microsoft.EntityFrameworkCore;
using MinecraftCastelo12303461.Models;

namespace MinecraftCastelo12303461.Context;

public class CasteloContext : DbContext
{
    public DbSet<Consulta> Consultas { get; set; }

    public string DbPath { get; set; }

    public CasteloContext()
    {
        var folder = Environment.SpecialFolder.LocalApplicationData;
        var path = Environment.GetFolderPath(folder);

        DbPath = Path.Join(path, "Castelo.db");
    }

    protected override void OnConfiguring(DbContextOptionsBuilder options)
        => options.UseSqlite($"Data Source={DbPath}");
}
