﻿using MinecraftCastelo12303461.Enum;

namespace MinecraftCastelo12303461.Models;

public class Consulta
{
    public int ConsultaId { get; set; }
    public Material MaterialUtilizado { get; set; }
    public int qtdeConstrutor { get; set; }
    public double TempoGasto { get; set; }
}
